<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-04 07:12:36 --> Severity: error --> Exception: Call to undefined function __construct() G:\Xampp\htdocs\codeigniter-ready-to-use\application\controllers\Home.php 7
ERROR - 2018-11-04 07:17:12 --> 404 Page Not Found: Home/index
ERROR - 2018-11-04 07:17:48 --> 404 Page Not Found: Home/index
ERROR - 2018-11-04 07:19:29 --> 404 Page Not Found: Home/tes
ERROR - 2018-11-04 07:19:37 --> 404 Page Not Found: Home_Controller/tes
ERROR - 2018-11-04 07:19:38 --> 404 Page Not Found: Home_Controller/tes
ERROR - 2018-11-04 07:19:38 --> 404 Page Not Found: Home_Controller/tes
ERROR - 2018-11-04 07:19:55 --> 404 Page Not Found: Home_Controller/tes
ERROR - 2018-11-04 07:20:43 --> Severity: error --> Exception: Too few arguments to function Home_Controller::index(), 0 passed in G:\Xampp\htdocs\codeigniter-ready-to-use\system\core\CodeIgniter.php on line 532 and exactly 1 expected G:\Xampp\htdocs\codeigniter-ready-to-use\application\controllers\Home_Controller.php 11
ERROR - 2018-11-04 07:20:49 --> Severity: error --> Exception: syntax error, unexpected '==' (T_IS_EQUAL), expecting ')' G:\Xampp\htdocs\codeigniter-ready-to-use\application\controllers\Home_Controller.php 11
ERROR - 2018-11-04 07:20:55 --> 404 Page Not Found: Home/tes
ERROR - 2018-11-04 07:21:04 --> 404 Page Not Found: Home/tes
ERROR - 2018-11-04 07:21:11 --> 404 Page Not Found: Home_Controller/tes
ERROR - 2018-11-04 07:21:12 --> 404 Page Not Found: Home_Controller/tes
ERROR - 2018-11-04 07:21:12 --> 404 Page Not Found: Home_Controller/tes
ERROR - 2018-11-04 07:21:12 --> 404 Page Not Found: Home_Controller/tes
ERROR - 2018-11-04 07:21:39 --> 404 Page Not Found: Home_Controller/tes
ERROR - 2018-11-04 07:21:52 --> 404 Page Not Found: Home/tes
ERROR - 2018-11-04 07:21:54 --> 404 Page Not Found: Home/index
ERROR - 2018-11-04 07:22:02 --> 404 Page Not Found: Home_controller/tes
ERROR - 2018-11-04 07:22:25 --> 404 Page Not Found: Home_controller_Controller/tes
ERROR - 2018-11-04 07:22:27 --> 404 Page Not Found: Home_controller_Controller/index
ERROR - 2018-11-04 07:25:45 --> 404 Page Not Found: Home/about
ERROR - 2018-11-04 07:25:51 --> 404 Page Not Found: Home/about
ERROR - 2018-11-04 07:26:02 --> 404 Page Not Found: Home/about
ERROR - 2018-11-04 07:26:06 --> 404 Page Not Found: Home/about
ERROR - 2018-11-04 07:29:49 --> 404 Page Not Found: Asdasd_Controller/index
ERROR - 2018-11-04 07:30:09 --> 404 Page Not Found: Asdasd_Controller/index
ERROR - 2018-11-04 07:30:12 --> 404 Page Not Found: Asdasd_Controller/index
ERROR - 2018-11-04 16:55:35 --> Severity: Notice --> Undefined variable: data G:\Xampp\htdocs\connectify\application\controllers\Home_Controller.php 12
