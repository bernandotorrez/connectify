<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-05 15:59:50 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\template.php 4
ERROR - 2018-11-05 16:00:19 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\template.php 4
ERROR - 2018-11-05 16:00:59 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\template.php 4
