<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-08 14:17:33 --> Query error: Duplicate entry 'akubernan' for key 'PRIMARY' - Invalid query: INSERT INTO `login` (`username`, `password`, `level`, `status`, `verifikasi`) VALUES ('akubernan', 'a7cd315a9b8f2e70c214f1ac760a5f7c', 'Participant', '0', '0')
ERROR - 2018-11-08 14:17:48 --> Query error: Duplicate entry 'akubernan' for key 'PRIMARY' - Invalid query: INSERT INTO `login` (`username`, `password`, `level`, `status`, `verifikasi`) VALUES ('akubernan', 'a7cd315a9b8f2e70c214f1ac760a5f7c', 'Participant', '0', '0')
ERROR - 2018-11-08 14:18:27 --> Query error: Duplicate entry 'akubernan1' for key 'PRIMARY' - Invalid query: INSERT INTO `login` (`username`, `password`, `level`, `status`, `verifikasi`) VALUES ('akubernan1', 'f7f2c5efc49f99d7ba932afb964ffe5e', 'Organizer', '0', '0')
ERROR - 2018-11-08 14:41:52 --> Severity: Notice --> session_write_close(): Skipping numeric key 0 Unknown 0
ERROR - 2018-11-08 14:42:19 --> Severity: Notice --> session_write_close(): Skipping numeric key 0 Unknown 0
ERROR - 2018-11-08 14:44:29 --> Severity: Notice --> Undefined index: username G:\Xampp\htdocs\connectify\application\controllers\Auth_Controller.php 35
ERROR - 2018-11-08 14:44:29 --> Severity: Notice --> Undefined index: level G:\Xampp\htdocs\connectify\application\controllers\Auth_Controller.php 36
ERROR - 2018-11-08 14:45:19 --> Severity: Notice --> Undefined variable: session G:\Xampp\htdocs\connectify\application\controllers\Auth_Controller.php 36
ERROR - 2018-11-08 14:46:34 --> Severity: Notice --> session_write_close(): Skipping numeric key 0 Unknown 0
ERROR - 2018-11-08 14:53:39 --> Severity: Notice --> session_write_close(): Skipping numeric key 0 Unknown 0
ERROR - 2018-11-08 14:54:12 --> Severity: Notice --> session_write_close(): Skipping numeric key 0 Unknown 0
ERROR - 2018-11-08 15:00:18 --> Severity: Notice --> session_write_close(): Skipping numeric key 0 Unknown 0
ERROR - 2018-11-08 15:05:08 --> Severity: Notice --> Undefined index: level G:\Xampp\htdocs\connectify\application\views\template\menu.php 86
ERROR - 2018-11-08 15:05:08 --> Severity: Notice --> Undefined index: level G:\Xampp\htdocs\connectify\application\views\template\menu.php 86
ERROR - 2018-11-08 15:05:08 --> Severity: Notice --> Undefined index: level G:\Xampp\htdocs\connectify\application\views\template\menu.php 86
ERROR - 2018-11-08 15:05:08 --> Severity: Notice --> Undefined index: level G:\Xampp\htdocs\connectify\application\views\template\menu.php 86
ERROR - 2018-11-08 15:05:08 --> Severity: Notice --> Undefined index: level G:\Xampp\htdocs\connectify\application\views\template\menu.php 86
ERROR - 2018-11-08 15:05:09 --> Severity: Notice --> Undefined index: level G:\Xampp\htdocs\connectify\application\views\template\menu.php 86
ERROR - 2018-11-08 15:05:09 --> Severity: Notice --> Undefined index: level G:\Xampp\htdocs\connectify\application\views\template\menu.php 86
