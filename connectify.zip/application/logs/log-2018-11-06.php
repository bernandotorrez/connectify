<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-06 15:42:23 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 60
ERROR - 2018-11-06 15:42:38 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 60
ERROR - 2018-11-06 15:43:11 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\controllers\Auth_Controller.php 13
ERROR - 2018-11-06 15:45:35 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\controllers\Auth_Controller.php 13
ERROR - 2018-11-06 15:47:07 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 60
ERROR - 2018-11-06 15:47:35 --> Severity: Notice --> Undefined index: url G:\Xampp\htdocs\connectify\application\controllers\Auth_Controller.php 13
ERROR - 2018-11-06 15:47:35 --> Severity: Warning --> A non-numeric value encountered G:\Xampp\htdocs\connectify\application\controllers\Auth_Controller.php 13
ERROR - 2018-11-06 15:48:16 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 60
ERROR - 2018-11-06 15:48:43 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 60
ERROR - 2018-11-06 15:53:11 --> Severity: Notice --> Undefined variable: aktif G:\Xampp\htdocs\connectify\application\views\template\menu.php 65
ERROR - 2018-11-06 15:53:24 --> Severity: Notice --> Undefined variable: aktif G:\Xampp\htdocs\connectify\application\views\template\menu.php 65
ERROR - 2018-11-06 15:53:32 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 6
ERROR - 2018-11-06 15:54:18 --> Severity: Notice --> Undefined variable: aktif G:\Xampp\htdocs\connectify\application\views\template\menu.php 65
ERROR - 2018-11-06 16:03:47 --> Severity: error --> Exception: syntax error, unexpected '-', expecting '(' G:\Xampp\htdocs\connectify\application\controllers\Home_Controller.php 21
ERROR - 2018-11-06 16:04:05 --> Severity: error --> Exception: syntax error, unexpected '.', expecting '(' G:\Xampp\htdocs\connectify\application\controllers\Home_Controller.php 21
ERROR - 2018-11-06 16:15:55 --> Query error: No database selected - Invalid query: SELECT *
FROM `login`
WHERE `username` = 'bernand'
AND `password` = '1cd74cdafc2f18437a7211b9e13d5f5f'
ERROR - 2018-11-06 16:16:08 --> Query error: No database selected - Invalid query: SELECT *
FROM `login`
WHERE `username` = 'bernan'
AND `password` = '6a3e6cffeea181ef8160d77d1ad4ce3b'
