<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-07 15:30:10 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 60
ERROR - 2018-11-07 15:30:10 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 80
ERROR - 2018-11-07 15:30:10 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 80
ERROR - 2018-11-07 15:30:10 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 80
ERROR - 2018-11-07 15:30:10 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\template.php 117
ERROR - 2018-11-07 15:30:10 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 60
ERROR - 2018-11-07 15:30:10 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 80
ERROR - 2018-11-07 15:30:10 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 80
ERROR - 2018-11-07 15:30:10 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 80
ERROR - 2018-11-07 15:30:10 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\template.php 117
ERROR - 2018-11-07 15:30:10 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 60
ERROR - 2018-11-07 15:30:10 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 80
ERROR - 2018-11-07 15:30:10 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 80
ERROR - 2018-11-07 15:30:10 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 80
ERROR - 2018-11-07 15:30:10 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\template.php 117
ERROR - 2018-11-07 15:30:10 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 60
ERROR - 2018-11-07 15:30:10 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 80
ERROR - 2018-11-07 15:30:10 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 80
ERROR - 2018-11-07 15:30:10 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 80
ERROR - 2018-11-07 15:30:10 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\template.php 117
ERROR - 2018-11-07 15:30:10 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 60
ERROR - 2018-11-07 15:30:10 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 80
ERROR - 2018-11-07 15:30:10 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 80
ERROR - 2018-11-07 15:30:10 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 80
ERROR - 2018-11-07 15:30:10 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\template.php 117
ERROR - 2018-11-07 15:30:10 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 60
ERROR - 2018-11-07 15:30:10 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 80
ERROR - 2018-11-07 15:30:10 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 80
ERROR - 2018-11-07 15:30:10 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 80
ERROR - 2018-11-07 15:30:10 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\template.php 117
ERROR - 2018-11-07 15:30:12 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 60
ERROR - 2018-11-07 15:30:12 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 80
ERROR - 2018-11-07 15:30:12 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 80
ERROR - 2018-11-07 15:30:12 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 80
ERROR - 2018-11-07 15:30:12 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\template.php 117
ERROR - 2018-11-07 15:30:12 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 60
ERROR - 2018-11-07 15:30:12 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 80
ERROR - 2018-11-07 15:30:12 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 80
ERROR - 2018-11-07 15:30:12 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\menu.php 80
ERROR - 2018-11-07 15:30:12 --> Severity: Notice --> Undefined variable: url G:\Xampp\htdocs\connectify\application\views\template\template.php 117
ERROR - 2018-11-07 15:42:59 --> Severity: error --> Exception: syntax error, unexpected '$params' (T_VARIABLE) G:\Xampp\htdocs\connectify\application\controllers\Auth_Controller.php 44
ERROR - 2018-11-07 15:43:44 --> Severity: error --> Exception: Call to undefined method Auth_Controller::post() G:\Xampp\htdocs\connectify\application\controllers\Auth_Controller.php 28
ERROR - 2018-11-07 15:43:48 --> Severity: error --> Exception: Call to undefined method Auth_Controller::post() G:\Xampp\htdocs\connectify\application\controllers\Auth_Controller.php 28
ERROR - 2018-11-07 15:48:10 --> Query error: Column 'level' cannot be null - Invalid query: INSERT INTO `login` (`username`, `password`, `level`, `status`, `verifikasi`) VALUES ('coba-insert', '42018a23a4f89d3c246d1808aed0c2ec', NULL, '0', '0')
ERROR - 2018-11-07 15:48:15 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `login` (`username`, `password`, `level`, `status`, `verifikasi`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, '0', '0')
ERROR - 2018-11-07 15:48:25 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `login` (`username`, `password`, `level`, `status`, `verifikasi`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, '0', '0')
ERROR - 2018-11-07 15:48:39 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `login` (`username`, `password`, `level`, `status`, `verifikasi`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, '0', '0')
ERROR - 2018-11-07 15:48:43 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `login` (`username`, `password`, `level`, `status`, `verifikasi`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, '0', '0')
ERROR - 2018-11-07 15:49:40 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `login` (`username`, `password`, `level`, `status`, `verifikasi`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, '0', '0')
ERROR - 2018-11-07 15:50:44 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `login` (`username`, `password`, `level`, `status`, `verifikasi`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, '0', '0')
ERROR - 2018-11-07 15:51:26 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `login` (`username`, `password`, `level`, `status`, `verifikasi`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, '0', '0')
ERROR - 2018-11-07 15:51:30 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `login` (`username`, `password`, `level`, `status`, `verifikasi`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, '0', '0')
ERROR - 2018-11-07 15:52:15 --> Query error: Column 'level' cannot be null - Invalid query: INSERT INTO `login` (`username`, `password`, `level`, `status`, `verifikasi`) VALUES ('admin@jujitsu-upn.online', '42018a23a4f89d3c246d1808aed0c2ec', NULL, '0', '0')
ERROR - 2018-11-07 15:52:33 --> Query error: Column 'level' cannot be null - Invalid query: INSERT INTO `login` (`username`, `password`, `level`, `status`, `verifikasi`) VALUES ('admin@jujitsu-upn.online', '42018a23a4f89d3c246d1808aed0c2ec', NULL, '0', '0')
ERROR - 2018-11-07 15:53:41 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `login` (`username`, `password`, `level`, `status`, `verifikasi`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, '0', '0')
ERROR - 2018-11-07 15:54:07 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `login` (`username`, `password`, `level`, `status`, `verifikasi`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, '0', '0')
ERROR - 2018-11-07 15:57:25 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `login` (`username`, `password`, `level`, `status`, `verifikasi`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, '0', '0')
ERROR - 2018-11-07 15:59:14 --> Query error: Duplicate entry 'admin@jujitsu-upn.online' for key 'PRIMARY' - Invalid query: INSERT INTO `login` (`username`, `password`, `level`, `status`, `verifikasi`) VALUES ('admin@jujitsu-upn.online', '42018a23a4f89d3c246d1808aed0c2ec', 'Organizer', '0', '0')
ERROR - 2018-11-07 15:59:26 --> Query error: Duplicate entry 'admin@jujitsu-upn.online' for key 'PRIMARY' - Invalid query: INSERT INTO `login` (`username`, `password`, `level`, `status`, `verifikasi`) VALUES ('admin@jujitsu-upn.online', '42018a23a4f89d3c246d1808aed0c2ec', 'Participant', '0', '0')
ERROR - 2018-11-07 16:07:16 --> Severity: error --> Exception: syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting '-' or identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) G:\Xampp\htdocs\connectify\application\models\Auth_Model.php 45
ERROR - 2018-11-07 16:08:42 --> Severity: error --> Exception: syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting '-' or identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) G:\Xampp\htdocs\connectify\application\models\Auth_Model.php 45
ERROR - 2018-11-07 16:14:14 --> Severity: error --> Exception: syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting '-' or identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) G:\Xampp\htdocs\connectify\application\models\Auth_Model.php 45
ERROR - 2018-11-07 16:14:38 --> Severity: Notice --> Undefined property: Auth_Controller::$Auth_model G:\Xampp\htdocs\connectify\application\controllers\Auth_Controller.php 48
ERROR - 2018-11-07 16:14:38 --> Severity: error --> Exception: Call to a member function cek_data() on null G:\Xampp\htdocs\connectify\application\controllers\Auth_Controller.php 48
ERROR - 2018-11-07 16:15:19 --> Severity: Notice --> Undefined property: Auth_Controller::$Auth_model G:\Xampp\htdocs\connectify\application\controllers\Auth_Controller.php 48
ERROR - 2018-11-07 16:15:19 --> Severity: error --> Exception: Call to a member function cek_data() on null G:\Xampp\htdocs\connectify\application\controllers\Auth_Controller.php 48
ERROR - 2018-11-07 16:16:07 --> Severity: Notice --> Undefined property: Auth_Controller::$Auth_model G:\Xampp\htdocs\connectify\application\controllers\Auth_Controller.php 48
ERROR - 2018-11-07 16:16:07 --> Severity: error --> Exception: Call to a member function cek_data() on null G:\Xampp\htdocs\connectify\application\controllers\Auth_Controller.php 48
ERROR - 2018-11-07 16:16:59 --> Severity: Notice --> Undefined property: Auth_Controller::$Auth_model G:\Xampp\htdocs\connectify\application\controllers\Auth_Controller.php 48
ERROR - 2018-11-07 16:16:59 --> Severity: error --> Exception: Call to a member function cek_data() on null G:\Xampp\htdocs\connectify\application\controllers\Auth_Controller.php 48
ERROR - 2018-11-07 16:17:01 --> Severity: Notice --> Undefined property: Auth_Controller::$Auth_model G:\Xampp\htdocs\connectify\application\controllers\Auth_Controller.php 48
ERROR - 2018-11-07 16:17:01 --> Severity: error --> Exception: Call to a member function cek_data() on null G:\Xampp\htdocs\connectify\application\controllers\Auth_Controller.php 48
ERROR - 2018-11-07 16:17:21 --> Severity: Notice --> Undefined property: Auth_Controller::$Auth_model G:\Xampp\htdocs\connectify\application\controllers\Auth_Controller.php 48
ERROR - 2018-11-07 16:17:21 --> Severity: error --> Exception: Call to a member function cek_data() on null G:\Xampp\htdocs\connectify\application\controllers\Auth_Controller.php 48
ERROR - 2018-11-07 16:17:47 --> Severity: Notice --> Undefined property: Auth_Controller::$Auth_model G:\Xampp\htdocs\connectify\application\controllers\Auth_Controller.php 48
ERROR - 2018-11-07 16:17:47 --> Severity: error --> Exception: Call to a member function cek_data() on null G:\Xampp\htdocs\connectify\application\controllers\Auth_Controller.php 48
ERROR - 2018-11-07 16:18:17 --> Severity: Notice --> Undefined property: Auth_Controller::$Auth_model G:\Xampp\htdocs\connectify\application\controllers\Auth_Controller.php 48
ERROR - 2018-11-07 16:18:17 --> Severity: error --> Exception: Call to a member function cek_data() on null G:\Xampp\htdocs\connectify\application\controllers\Auth_Controller.php 48
ERROR - 2018-11-07 16:18:50 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `login` (`username`, `password`, `level`, `status`, `verifikasi`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, '0', '0')
ERROR - 2018-11-07 16:18:58 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int G:\Xampp\htdocs\connectify\application\models\Auth_Model.php 49
ERROR - 2018-11-07 16:19:11 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `login` (`username`, `password`, `level`, `status`, `verifikasi`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, '0', '0')
ERROR - 2018-11-07 16:23:47 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `login` (`username`, `password`, `level`, `status`, `verifikasi`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, '0', '0')
ERROR - 2018-11-07 16:24:03 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `login` (`username`, `password`, `level`, `status`, `verifikasi`) VALUES (NULL, 'd41d8cd98f00b204e9800998ecf8427e', NULL, '0', '0')
ERROR - 2018-11-07 16:25:43 --> Query error: Duplicate entry 'admin@jujitsu-upn.online' for key 'PRIMARY' - Invalid query: INSERT INTO `login` (`username`, `password`, `level`, `status`, `verifikasi`) VALUES ('admin@jujitsu-upn.online', '42018a23a4f89d3c246d1808aed0c2ec', 'Organizer', '0', '0')
