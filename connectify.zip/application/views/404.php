
<html>
<head>
<title><?=$title;?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<link href="<?=base_url('template/assets/404/web/css/style.css');?>" rel="stylesheet" type="text/css" media="all" />

</head>
<body>
	<!-----start-wrap--------->
	<div class="wrap">
		<!-----start-content--------->
		<div class="content">
			<!-----start-logo--------->
			<div class="logo">
				<h1><img src="<?=base_url('template/assets/404/web/images/logo.png');?>"/></h1>
			
				<span><img src="<?=base_url('template/assets/404/web/images/signal.png');?>"/>Oops! The Page you requested was not found!</span>
			</div>
			<!-----end-logo--------->
			<!-----start-search-bar-section--------->
			<div class="buttom">
				<div class="seach_bar">
				    <br>
					<p>Back to <span><a href="<?=base_url('home');?>">Home</a></span></p>
					<!-----start-sear-box--------->
					
				</div>
			</div>
			<!-----end-sear-bar--------->
		</div>
		<!----copy-right-------------->
	<p class="copy_right">&#169; 2014 Template by<a href="http://w3layouts.com" target="_blank">&nbsp;w3layouts</a> </p>
	</div>
	
	<!---------end-wrap---------->
</body>
</html>